package co.martinbaciga.drawingtest.domain.provider;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {
}
